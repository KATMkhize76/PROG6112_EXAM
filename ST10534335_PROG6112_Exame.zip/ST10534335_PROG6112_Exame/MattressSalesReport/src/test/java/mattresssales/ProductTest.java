package mattresssales;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests required by the assignment.
 */
class ProductTest {
    private Product product;

    @BeforeEach
    void setUp() {
        String[] names = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };
        int[][] sales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };
        product = new Product(names, sales);
    }

    @Test
    void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(153, product.GetTotalProductsSold());
    }

    @Test
    void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(17.0, product.GetAverageProductSold(), 0.0001);
    }

    @Test
    void GetMostPopularProduct_WithValidData_ReturnsProductWithHighestTotal() {
        assertEquals("Cozy Nights Monarch (63)", product.GetMostPopularProduct());
    }
}
