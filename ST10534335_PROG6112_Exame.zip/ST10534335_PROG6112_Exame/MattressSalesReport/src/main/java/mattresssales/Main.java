package mattresssales;

import java.util.Scanner;

/**
 * Main program: collects three months of sales for three mattress products.
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Single-dimensional array containing the three product names.
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // Two-dimensional array: rows are products and columns are months.
        int[][] monthlySales = new int[productNames.length][3];

        for (int product = 0; product < productNames.length; product++) {
            for (int month = 0; month < 3; month++) {
                monthlySales[product][month] = readSales(
                    input, month + 1, productNames[product]
                );
            }
            System.out.println();
        }

        Product productReport = new Product(productNames, monthlySales);
        PrintProduct printer = new PrintProduct(productReport);
        printer.PrintReport();

        input.close();
    }

    private static int readSales(Scanner input, int month, String productName) {
        while (true) {
            System.out.print("Enter number of sales for month " + month
                    + " for " + productName + ": ");
            if (input.hasNextInt()) {
                int sales = input.nextInt();
                if (sales >= 0) {
                    return sales;
                }
                System.out.println("Please enter zero or a positive number.");
            } else {
                System.out.println("Invalid input. Please enter a whole number.");
                input.next(); // discard invalid input
            }
        }
    }
}
