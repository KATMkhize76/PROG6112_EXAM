package mattresssales;

/**
 * Defines the operations available for the mattress product sales report.
 */
public interface IProduct {
    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}
