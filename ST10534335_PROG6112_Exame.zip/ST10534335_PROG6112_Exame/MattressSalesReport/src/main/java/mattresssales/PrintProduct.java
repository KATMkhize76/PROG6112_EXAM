package mattresssales;

/**
 * Handles displaying the sales report.
 */
public class PrintProduct {
    private final IProduct product;

    public PrintProduct(IProduct product) {
        if (product == null) {
            throw new IllegalArgumentException("Product report cannot be null.");
        }
        this.product = product;
    }

    public void PrintTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales() {
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductSold());
    }

    public void PrintMostPopularProductSales() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }

    public void PrintReport() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("**********************************************");
        PrintTotalProductSales();
        PrintAverageProductSales();
        PrintMostPopularProductSales();
    }
}
