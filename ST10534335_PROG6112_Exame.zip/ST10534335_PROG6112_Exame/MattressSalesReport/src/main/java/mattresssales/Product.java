package mattresssales;

/**
 * Stores product names and monthly sales, and calculates sales statistics.
 * The product names use a one-dimensional array and monthly sales use a
 * two-dimensional array (one row per product and one column per month).
 */
public class Product implements IProduct {
    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        if (productNames == null || monthlySales == null) {
            throw new IllegalArgumentException("Product names and sales data cannot be null.");
        }
        if (productNames.length == 0 || monthlySales.length != productNames.length) {
            throw new IllegalArgumentException("Each product must have one sales row.");
        }

        this.productNames = productNames.clone();
        this.monthlySales = new int[monthlySales.length][];

        for (int i = 0; i < productNames.length; i++) {
            if (productNames[i] == null || productNames[i].isBlank()) {
                throw new IllegalArgumentException("Product names cannot be blank.");
            }
            if (monthlySales[i] == null || monthlySales[i].length != 3) {
                throw new IllegalArgumentException("Each product must have sales for exactly three months.");
            }
            this.monthlySales[i] = monthlySales[i].clone();
            for (int sale : this.monthlySales[i]) {
                if (sale < 0) {
                    throw new IllegalArgumentException("Sales values cannot be negative.");
                }
            }
        }
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] productSales : monthlySales) {
            for (int sale : productSales) {
                total += sale;
            }
        }
        return total;
    }

    /**
     * Returns the average number sold per product-month entry.
     * For three products over three months, the total is divided by nine.
     */
    @Override
    public double GetAverageProductSold() {
        int numberOfEntries = 0;
        for (int[] productSales : monthlySales) {
            numberOfEntries += productSales.length;
        }
        return (double) GetTotalProductsSold() / numberOfEntries;
    }

    /**
     * Returns the product with the highest combined sales across all months.
     * If products are tied, the first product in the supplied array is returned.
     */
    @Override
    public String GetMostPopularProduct() {
        int highestTotal = Integer.MIN_VALUE;
        int popularIndex = 0;

        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;
            for (int sale : monthlySales[i]) {
                productTotal += sale;
            }
            if (productTotal > highestTotal) {
                highestTotal = productTotal;
                popularIndex = i;
            }
        }
        return productNames[popularIndex] + " (" + highestTotal + ")";
    }
}
