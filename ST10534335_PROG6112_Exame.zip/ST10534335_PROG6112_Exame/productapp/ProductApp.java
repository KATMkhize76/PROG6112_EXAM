package productapp;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import javax.swing.*;

public class ProductApp extends JFrame {
    private final JTextField customerNameField = new JTextField();
    private final JComboBox<String> productComboBox = new JComboBox<>(new String[] {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    });
    private final JTextField priceField = new JTextField();
    private final JButton processButton = new JButton("PROCESS");

    public ProductApp() {
        setTitle("Product App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(560, 330);
        setLocationRelativeTo(null);
        setJMenuBar(createMenuBar());

        JPanel form = new JPanel(new GridLayout(4, 2, 12, 18));
        form.setBorder(BorderFactory.createEmptyBorder(35, 30, 35, 30));
        form.add(new JLabel("Customer Name:"));
        form.add(customerNameField);
        form.add(new JLabel("Select Product:"));
        form.add(productComboBox);
        form.add(new JLabel("Enter Price:"));
        form.add(priceField);
        form.add(new JLabel(""));
        form.add(processButton);

        add(form, BorderLayout.CENTER);
        processButton.addActionListener(event -> processSale());
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(event -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        processItem.addActionListener(event -> processSale());
        clearItem.addActionListener(event -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    private void processSale() {
        String customerName = customerNameField.getText().trim();
        String selectedProduct = (String) productComboBox.getSelectedItem();
        String enteredPrice = priceField.getText().trim();

        if (customerName.isEmpty()) {
            showError("Please enter the customer's name.");
            customerNameField.requestFocus();
            return;
        }
        if (enteredPrice.isEmpty()) {
            showError("Please enter the product price.");
            priceField.requestFocus();
            return;
        }

        final double price;
        try {
            price = Double.parseDouble(enteredPrice);
            if (!Double.isFinite(price) || price < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            showError("Please enter a valid price (zero or greater).");
            priceField.requestFocus();
            return;
        }

        ProductCalculations calculations = new ProductCalculations(price);
        double vat = calculations.GetVat();
        double commission = calculations.GetCommission();
        double total = calculations.GetTotal();

        String report = String.format(
            "Customer Name: %s%nProduct: %s%nVAT: R %.2f%nCOMMISSION: R %.2f%nTOTAL: R %.2f",
            customerName, selectedProduct, vat, commission, total
        );

        try {
            saveToFile(customerName, selectedProduct, vat, commission, total);
        } catch (IOException ex) {
            showError("The sale was calculated, but data.txt could not be saved: " + ex.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(this, report, "Message", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveToFile(String customerName, String product, double vat,
                            double commission, double total) throws IOException {
        String entry = String.format(
            "DATA LOG%n****************************************%nCustomer Name: %s%nProduct: %s%nVAT: R %.2f%nCOMMISSION: R %.2f%nTOTAL: R %.2f%n****************************************%n",
            customerName, product, vat, commission, total
        );
        Files.writeString(
            Path.of("data.txt"),
            entry + System.lineSeparator(),
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,
            StandardOpenOption.APPEND
        );
    }

    private void clearForm() {
        customerNameField.setText("");
        priceField.setText("");
        productComboBox.setSelectedIndex(0);
        customerNameField.requestFocus();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
